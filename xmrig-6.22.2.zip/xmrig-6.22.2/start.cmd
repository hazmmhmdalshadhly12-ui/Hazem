@echo off
cd /d "%~dp0"
xmrig.exe -o gulf.moneroocean.stream:10128 -u 4B6Er3repdu7nr5q99Dh3qbiWvxmVU7Kg5g42pBftdLTRfvi6pNjKYk3iGGcDTDsL4HvbAtFjsdqhRED6RVxgh5uGpxUHwp -p x --donate-level=1
pause
